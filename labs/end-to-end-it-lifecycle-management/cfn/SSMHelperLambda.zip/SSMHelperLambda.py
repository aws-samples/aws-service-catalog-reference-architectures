# Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#!/usr/bin/env python
import json
from botocore.vendored import requests
import sys
import base64
import os
import boto3

'''

This module creates SSM parameters for access keys and secret access keys created as a part of this lab

'''

__version__ = '1.0'
__author__ = '@SYK@'
__email__ = 'khasnis@'

def respond_cloudformation(event, status, message, data):
    responseBody = {
        'Status': status,
        'Reason': message,
        'PhysicalResourceId': event['ServiceToken'],
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    print('Response = ' + json.dumps(responseBody))
    print(event)
    requests.put(event['ResponseURL'], data=json.dumps(responseBody))

def delete_respond_cloudformation(event, status, message, data):
    responseBody = {
        'Status': status,
        'Reason': 'See the details in CloudWatch Log Stream',
        'PhysicalResourceId': event['ServiceToken'],
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    print('Response = ' + json.dumps(responseBody))
    print(event)
    lambda_client = boto3.client('lambda')
    function_name = os.environ['AWS_LAMBDA_FUNCTION_NAME']
    print('Deleting Lambda')
    lambda_client.delete_function(FunctionName=function_name)
    requests.put(event['ResponseURL'], data=json.dumps(responseBody))

def handler(event, context):
    print(event)
    sc_enduser_pub_key = event['ResourceProperties']['SCEndUserPubKey']
    sc_enduser_secret_key = event['ResourceProperties']['SCEndUserSecretKey']
    sc_syncuser_pub_key = event['ResourceProperties']['SCSyncUserPubKey']
    sc_syncuser_secret_key = event['ResourceProperties']['SCSyncUserSecretKey']
    
    if (event['RequestType'] == 'Create'):
        try:
            client = boto3.client('ssm')
            #store public key for Service Catalog End User
            response = client.put_parameter(
                                            Name='SCEndUser-PublicAccessKey',
                                            Description='SSM Parameter for SCEndUser Public Access Key.',
                                            Value=str(sc_enduser_pub_key),
                                            Type='String',
                                            Overwrite=True
                                        )
            print(str(response))

            #store secret key for Service Catalog End User
            response = client.put_parameter(
                                            Name='SCEndUser-SecretAccessKey',
                                            Description='SSM Parameter for SCEndUser Secret Access Key.',
                                            Value=str(sc_enduser_secret_key),
                                            Type='SecureString',
                                            Overwrite=True
                                        )
            print(str(response))

            #store public key for Service Catalog Sync User
            response = client.put_parameter(
                                            Name='SCSyncUser-PublicAccessKey',
                                            Description='SSM Parameter for SCSyncUser Public Access Key.',
                                            Value=str(sc_syncuser_pub_key),
                                            Type='String',
                                            Overwrite=True
                                        )
            print(str(response))

            #store secret key for Service Catalog Sync User
            response = client.put_parameter(
                                            Name='SCSyncUser-SecretAccessKey',
                                            Description='SSM Parameter for SCSyncUser Secret Access Key.',
                                            Value=str(sc_syncuser_secret_key),
                                            Type='SecureString',
                                            Overwrite=True
                                        )
            print(str(response))
            respond_cloudformation(event, "SUCCESS", "Check CloudWatch logs for details", { "Message": "Creation of SSM parameters completed!"})
        except Exception as ex:
            template = "An exception of type {0} occurred. Arguments:\n{1!r} "
            message = template.format(type(ex).__name__, ex.args)
            print(message)
            respond_cloudformation(event, "FAILED","Check CloudWatch logs for details", { "Message": "Creation of SSM parameters failed!"})
    
    if(event['RequestType'] == 'Update'):
        print("Update in progress")
        respond_cloudformation(event, "SUCCESS","Check CloudWatch logs for details", { "Message": "Resource update successful!" })
    
    elif(event['RequestType'] == 'Delete'):
        try:
            delete_respond_cloudformation(event, "SUCCESS","Check CloudWatch logs for details", {"Message":"Delete Request Initiated. Deleting Lambda Function."})
        except:
            print("Couldnt initiate delete response.")
