import boto3
import json
import logging
import os

# import urllib.request
import requests
from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
from urllib.parse import urlparse
import time

logging.basicConfig(level=logging.INFO)

session = boto3.Session()
region = session.region_name


def on_event(event, context):
    print(f"Event: {event},\n Context: {context}")
    request_type = event["RequestType"]
    if request_type == "Create":
        return on_create(event, context)
    if request_type == "Update":
        return on_update(event)
    if request_type == "Delete":
        return on_delete(event)
    raise Exception("Invalid request type: %s" % request_type)


def on_create(event, context):
    props = event["ResourceProperties"]
    print("create new resource with props %s" % props)

    # Extract properties from the event
    collection_endpoint = props["CollectionEndpoint"]

    url = urlparse(collection_endpoint)
    host = url.netloc
    port = 443
    service = "aoss"

    credentials = session.get_credentials()

    auth = AWSV4SignerAuth(credentials=credentials, region=region, service=service)

    client = OpenSearch(
        hosts=[{"host": host, "port": port}],
        http_auth=auth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
    )

    index_name = "bedrock-knowledge-base-demo-default-index"
    index_body = {
        "settings": {"index.knn": True},
        "mappings": {
            "properties": {
                "bedrock-knowledge-base-demo-default-vector": {
                    "type": "knn_vector",
                    "dimension": 1536,
                    "method": {
                        "name": "hnsw",
                        "engine": "faiss",
                        "parameters": {
                            "ef_construction": 512,
                            "m": 16,
                        },
                    },
                }
            }
        },
    }

    wait_condition_handle_url = os.environ.get("WAIT_CONDITION_HANDLE_URL")
    status = "FAILURE"
    reason = ""

    try:
        client.indices.create(index=index_name, body=index_body)
        print(f"Vector index '{index_name}' created successfully.")

        i = 0
        while i < 3:
            response = client.indices.exists(index=index_name)
            if response:
                print(f"Vector index: '{index_name}' exists.")
                status = "SUCCESS"
                reason = "Index created successfully."
                break
            i += 1
            time.sleep(5)

        if status == "FAILURE":
            reason = "Index creation failed after multiple attempts."

        signal_data = {
            "Status": status,
            "UniqueId": context.aws_request_id,
            "Data": reason,
            "Reason": reason,
        }
        print(f"Signal Data to be sent to CFN: {signal_data}")
        print("Sleeping for 15 seconds before sending signal")
        time.sleep(15)
        send_signal(wait_condition_handle_url, signal_data)
        physical_id = "CreateIndex"
        return {"PhysicalResourceId": physical_id}

    except Exception as e:
        print(f"Error ': {e}")
        reason = str(e)
        signal_data = {
            "Status": "FAILURE",
            "UniqueId": context.aws_request_id,
            "Data": reason,
            "Reason": reason,
        }
        return None


def on_update(event):
    physical_id = event["PhysicalResouceId"]
    props = event["ResourceProperties"]
    print("update resource %s with props %s" % (physical_id, props))

    # Add update code here


def on_delete(event):
    physical_id = event["PhysicalResourceId"]
    props = event["ResourceProperties"]
    collection_endpoint = props["CollectionEndpoint"]
    physical_id = props["PhysicalResourceId"]
    print("resource id: %s" % physical_id)
    print("AOS Collection has been deleted by the CloudFormation: %s" % props)
    # images = ecr_client.list_images(repositoryName = repository)
    # for image in images["imageIds"]:
    #     image_id_list = image

    # try:
    #     if images:
    #         ecr_client.batch_delete_image(
    #             imageIds=[image_id_list], repositoryName=repository
    #         )
    #         print("successfully deleted images")
    # except ClientError as e:
    #     logging.error(e)


def send_signal(wait_condition_handle_url, signal_data):
    if wait_condition_handle_url:
        try:
            headers = {"Content-Type": "application/json"}
            data = json.dumps(signal_data)
            response = requests.put(
                wait_condition_handle_url, headers=headers, data=data
            )
            print(response.text)
            print("Signal successfully sent")
        except Exception as e:
            logging.error(f"Error sending signal to WaitCondition: {e}")
