import json
import sys
import os
import shutil
import boto3
import re
from botocore.exceptions import ClientError
from subprocess import run
import urllib.request
from zipfile import ZipFile
from collections import OrderedDict


def on_event(event,context):
    print(event)
    request_type = event['RequestType']
    if request_type == 'Create':
        return on_create(event)
    if request_type == 'Update':
        return on_update(event)
    if request_type == 'Delete':
        return on_delete(event)
    raise Exception("Invalid request type: %s" % request_type)

def on_create(event):
    props = event["ResourceProperties"]
    print("create new resource with props %s" % props)

    required_fields = ['s3_bucket', 'libraries']

    # Validate fields
    validate = validate_fields(props, required_fields)
    if not validate and len(validate) > 1:
        return validate
    
    # test connection to S3 bucket
    bucket_name = props['s3_bucket']
    s3 = boto3.resource('s3')
    Bucket = s3.Bucket(bucket_name)

    try:
        Bucket.objects.limit(count=1)
    except Exception as e:
        return f'Unable to connect to S3 bucket: {bucket_name}\nError: {e}'
    
    # create layer
    layer_name = create_upload_layer(props, Bucket)

    print(f'Created layer: {layer_name}')

    
    return { 'PhysicalResourceId': layer_name }

def on_update(event):
    physical_id = event["PhysicalResouceId"]
    props = event["ResourceProperties"]
    print("update resource %s with props %s" % (physical_id, props))

    # Add update code here

def on_delete(event):
    physical_id = event["PhysicalResourceId"]
    props = event["ResourceProperties"]
    print(f'Custom resource deleted by CloudFormation Stack: {physical_id}')


# Create new lambda layer function
def create_upload_layer(props, Bucket):
    
    version_number = run(['python', '--version'], capture_output=True, text=True).stdout.split()[1].replace('.','_')
    file_name = f'opensearchpy-{version_number}.zip'
    python_dir = '/tmp/python'
    layer_path = f'{python_dir}/{file_name}'

    # clean local /tmp directory
    run(['rm', '-rf', '/tmp/*'])
    # create layer directory
    run(['mkdir', python_dir])

    #install python packages
    for library in props['libraries']:
        run(['python', '-m', 'pip', 'install', library, '-t', python_dir])

    # Calculate layer size
    dir_size = run(['du', '-sh', python_dir], capture_output=True, text=True)
    dir_size = dir_size.stdout.split()[0]
    dir_size = dir_size.split('M')[0]
    dir_size = re.findall(r'\d+', dir_size)[0]

    if int(dir_size) >= 250:
        print('Layer size is greater than 250MB. Consider removing unnecessary libraries...')

    zipdir(python_dir, layer_path)

    # Upload layer to S3 bucket
    try:
        Bucket.upload_file(layer_path, file_name)
    except Exception as e:
        return f'Error uploading layer to S3: {e}'
    
    return file_name
        

# Validate fields function
def validate_fields(props, required):
    fields = ""
    keys = ""
    values = ""

    # Check if required fields are present
    keys = list(OrderedDict.fromkeys(required).keys() - set(props.keys()))
    values = [key for key, value in filter(lambda item: not item[1] or len(item[1]) <= 0, props.items())]

    if keys:
        fields = f'Missing Keys: {keys}'
    if values:
        fields = f'{fields} *** Missing values: {str(values)}'

    return fields

# Zip directory function
def zipdir(source_path, output_path):
    with ZipFile(output_path, 'w') as zipObj:
        s_path_len = len(source_path)
        for root, _, files in os.walk(source_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipObj.write(file_path, f'python/{file_path[s_path_len:]}')
        