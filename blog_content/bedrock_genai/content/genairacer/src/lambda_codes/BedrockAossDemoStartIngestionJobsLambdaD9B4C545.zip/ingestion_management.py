import boto3
import json
import logging
import os

# Set up logging
logging.basicConfig(level=logging.INFO)

# Create a BEDROCK Agent client
print("Creating BEDROCK Agent client")
bedrock_agent_client = boto3.client('bedrock-agent')

def lambda_handler(event, context):
    """
    Lambda function to handle the ingestion management event.
    """
    print("Received event in lambda_handler")
    logging.info(f"Received event: {event}")

    # Synchronize the knowledge base with the data source
    print("Calling sync_knowledge_base function")
    response = sync_knowledge_base()
    print("Received response from sync_knowledge_base function")
    logging.info(f"Response: {response}")

def sync_knowledge_base():
    """
    Synchronizes the specified knowledge base with the data source.
    """
    print("Inside sync_knowledge_base function")

    # Extract the data source ID and knowledge base ID from environment variables
    data_source_id = os.environ['DATA_SOURCE_ID']
    knowledge_base_id = os.environ['KNOWLEDGE_BASE_ID']

    logging.info(f"Syncing knowledge base {knowledge_base_id} with data source {data_source_id}")
    
    try:
        print("Calling start_ingestion_job on BEDROCK Agent client")
        bedrock_response = bedrock_agent_client.start_ingestion_job(
            dataSourceId = data_source_id,
            knowledgeBaseId = knowledge_base_id
        )
        print("Received response from start_ingestion_job")
        logging.info(f"Ingestion job started for knowledge base {knowledge_base_id} with data source {data_source_id}")
        logging.info(f"Response: {bedrock_response}")
        return bedrock_response
    
    except Exception as e:
        print("Error occurred in sync_knowledge_base function")
        logging.error(f"Error synchronizing knowledge base {knowledge_base_id} with data source {data_source_id}\nError: {e}")