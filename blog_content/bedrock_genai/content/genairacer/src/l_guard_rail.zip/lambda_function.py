import boto3
import json
import datetime
import random
import time

bedrock = boto3.client('bedrock')

class DateEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        return json.JSONEncoder.default(self, obj)
        
        
def bdgaurdcreatev11(gdata):
    
    # Define the guardrail configuration

    guardrail_config = {
        "name": gdata['name'],
        "description": gdata['description'],
        "topicPolicyConfig": gdata['topicPolicyConfig'],
        "contentPolicyConfig": gdata['contentPolicyConfig'],
        "blockedInputMessaging": "Input contains sensitive information and has been blocked.",
        "blockedOutputsMessaging": "Response contains sensitive information and has been blocked."
    }
    
    try:
        # Create the guardrail
        response = bedrock.create_guardrail(**guardrail_config)
        
        return {
            
            'body': json.dumps({
                'message': 'Guardrail created successfully',
                'guardrailId': response['guardrailId'],
                'guardrailArn': response['guardrailArn']
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error creating guardrail',
                'error': str(e)
            })
        }
def bdgaurdcreate():
    
    # Define the guardrail configuration
    _rand  = random.randint(10, 24200)
    gname = f"guardrailmp{_rand}"
     
    guardrail_config = {
        "name": f"PIIProtectionGuardrail{_rand}",
        "description": "Guardrail to protect Personally Identifiable Information",
        "topicPolicyConfig": {
            "topicsConfig": [
                {
                    "name": gname,
                    "definition": "Personally Identifiable Information",
                    "type": "DENY",
                    "examples": [
                        "My social security number is 123-45-6789",
                        "John Doe's credit card number is 1234-5678-9012-3456"
                    ]
                }
            ]
        },
        "contentPolicyConfig": {
            "filtersConfig": [
                {
                    "type": "MISCONDUCT",
                    "inputStrength": "MEDIUM",
                    "outputStrength": "HIGH"
                }
            ]
        },
        "blockedInputMessaging": "Input contains sensitive information and has been blocked.",
        "blockedOutputsMessaging": "Response contains sensitive information and has been blocked."
    }
    
    try:
        # Create the guardrail
        response = bedrock.create_guardrail(**guardrail_config)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Guardrail created successfully',
                'guardrailId': response['guardrailId'],
                'guardrailArn': response['guardrailArn']
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error creating guardrail',
                'error': str(e)
            })
        }
def list_guardrails(max_results=None, next_token=None):
   
    params = {}
    if max_results:
        params['maxResults'] = max_results
    if next_token:
        params['nextToken'] = next_token
    
    try:
        response = bedrock.list_guardrails(**params)
        
        guardrails = response.get('guardrails', [])
        next_token = response.get('nextToken')
        
        return guardrails
    
    except Exception as e:
        print(f"Error listing guardrails: {str(e)}")
        return []



def deleteguarail(id,version):
    try:
        response = bedrock.delete_guardrail(guardrailIdentifier=id)
    except Exception as e:
        print(f"Error listing guardrails: {str(e)}")
        response = f"Error listing guardrails: {str(e)}"
    return response

    
def lambda_handler(event, context):
    print(json.dumps(event))
    
    if event['requestContext']['httpMethod'] == 'GET':
        _ret = list_guardrails(max_results=10)
        _bod= {'guardrails': _ret}
        _ret = json.dumps(_bod, cls=DateEncoder)
        return {
            'statusCode': 200,
            "isBase64Encoded": False,
            "headers": {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body':   _ret }
    if event['requestContext']['httpMethod'] == 'POST':
        grdata = json.loads(event['body'])
        if grdata['act'] == 'delete':
            deleteguarail(grdata['gaurailid'],grdata['version'])
            time.sleep(4)
            
            _ret ={'message':f'Deleting {grdata['gaurailid']} version {grdata['version']}'}
            
            return {
                'statusCode': 200,
                "isBase64Encoded": False,
                "headers": {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
                'body':   json.dumps(_ret)}
        if grdata['act'] == 'create':
            _ret=bdgaurdcreatev11(grdata)
            return {
                'statusCode': 200,
                "isBase64Encoded": False,
                "headers": {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
                'body':   json.dumps(_ret)}
    print(json.dumps(_ret, cls=DateEncoder))
        
  