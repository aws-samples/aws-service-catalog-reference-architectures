
          let oidcConfig;
          exports.handler = async function(event, context) {
            //return '3rro';
            // Prep response
            const response = {
              "principalId": "unauthenticated-user",
              "policyDocument": {
                "Version": "2012-10-17",
                "Statement": [
                  {
                    "Action": "execute-api:Invoke",
                    "Effect": "Allow",
                    "Resource": event.methodArn
                  }
                ]
              },
              "context": {
                "responseOverrideString": JSON.stringify({
                  statusCode: 500,
                  headers: {
                    "Content-type": "text/plain"
                  },
                  body: "Internal server error"
                })
              }
            };
            // Grab OIDC configuration if not already done
            if (!oidcConfig) {
              try {
                let oidcResponse = await sendRequest(process.env.OidcConfigurationUrl);
                let oidcResponseParsed = JSON.parse(oidcResponse.responseText);
                if (!oidcResponseParsed) {
                  throw new Error("No OIDC configuration");
                }
                oidcConfig = oidcResponseParsed;
              } catch (e) {
                console.error("Error trying to get OIDC configuration:", e.message);
                return response;
              }
            }
            // Prep redirect URL
            const redirectUrl = `https://${event.requestContext.domainName}${event.requestContext.path}`;
            // Grab cookie header
            const cookieValue = event.headers.Cookie ? event.headers.Cookie : event.headers.cookie;
            const cookieMap = getCookieMapFromValue(cookieValue);
            const jwt = cookieMap && cookieMap.id_token ? parseJWT(cookieMap.id_token) : false;
            // If GET method and code provided in query string, return HTML and use AJAX to get tokens
            if (event.httpMethod == "GET" && event.queryStringParameters.code){
              response.context.responseOverrideString = JSON.stringify({
                statusCode: 200,
                headers: {
                  "Content-type": "text/html"
                },
                body: getInterstitialHTML(redirectUrl)
              });
              return response;
            }
            // If POST method and code provided in query string, return cookies and JSON with tokens
            if (event.httpMethod == "POST" && event.queryStringParameters.code) {
              try {
                const tokens = await getTokenFromCode(oidcConfig, process.env.ClientId, event.queryStringParameters.code, redirectUrl);
                if (tokens.error) {
                  console.error(`Error from getting token: ${JSON.stringify(tokens)}`);
                  response.context.responseOverrideString = JSON.stringify({
                    statusCode: 200,
                    headers: {
                      "Content-type": "application/json"
                    },
                    body: JSON.stringify({error: ["invalid_grant"].indexOf(tokens.error) != -1 ? tokens.error : "other_error"})
                  });
                  return response;
                }
                const fingerprint = getFingerprint();
                response.context.responseOverrideString = JSON.stringify({
                  statusCode: 200,
                  multiValueHeaders: {
                    "Content-type": ["application/json"],
                    "Set-Cookie": [
                      `id_token=${tokens.id_token}; Domain=${event.requestContext.domainName}; Path=/; SameSite=${process.env.IdTokenCookieSameSite}; Secure`,
                      `fingerprint_raw=${fingerprint.raw}; Domain=${event.requestContext.domainName}; HttpOnly; Path=${event.requestContext.path}; SameSite=Strict; Secure`
                    ]
                  },
                  body: JSON.stringify({
                    id_token: tokens.id_token,
                    refresh_token: tokens.refresh_token,
                    fingerprint_hash: fingerprint.hash
                  })
                });
              } catch (e) {
                console.error("Error trying to get tokens from code:", e.message);
              }
              return response;
            }
            // If POST method and refresh token and fingerprint (hash) provided in query string, return cookie and JSON with tokens
            if (event.httpMethod == "POST" && event.queryStringParameters.refresh && event.queryStringParameters.fingerprint) {
              try {
                if (!cookieMap || !cookieMap.fingerprint_raw || hashFingerprintRaw(cookieMap.fingerprint_raw) != event.queryStringParameters.fingerprint) {
                  console.error(`Hash of fingerprint raw (JSON.stringify(${cookieMap.fingerprint_raw})) does not match fingerprint hash (${JSON.stringify(event.queryStringParameters.fingerprint)}).`);
                  response.context.responseOverrideString = JSON.stringify({
                    statusCode: 200,
                    headers: {
                      "Content-type": "application/json"
                    },
                    body: JSON.stringify({error: "invalid_fingerprint"})
                  });
                  return response;
                }
                const tokens = await getTokenFromRefreshToken(oidcConfig, process.env.ClientId, event.queryStringParameters.refresh, redirectUrl);
                if (tokens.error) {
                  console.error(`Error from getting token: ${JSON.stringify(tokens)}`);
                  response.context.responseOverrideString = JSON.stringify({
                    statusCode: 200,
                    headers: {
                      "Content-type": "application/json"
                    },
                    body: JSON.stringify({error: ["invalid_grant"].indexOf(tokens.error) != -1 ? tokens.error : "other_error"})
                  });
                  return response;
                }
                response.context.responseOverrideString = JSON.stringify({
                  statusCode: 200,
                  headers: {
                    "Content-type": "application/json",
                    "Set-Cookie": `id_token=${tokens.id_token}; Domain=${event.requestContext.domainName}; Path=/; SameSite=${process.env.IdTokenCookieSameSite}; Secure`
                  },
                  body: JSON.stringify({
                    id_token: tokens.id_token,
                    refresh_token: tokens.refresh_token
                  })
                });
              } catch (e) {
                console.error("Error trying to get tokens from code:", e.message);
              }
              return response;
            }
            // If GET method and cookie has valid JWT, allow through without response override
            if (event.httpMethod == "GET" && jwt && isJWTExpired(jwt)) {
              // JWT exists, but expired. Continue to redirect.
              console.log("JWT expired. Redirecting.");
            } else if (event.httpMethod == "GET" && jwt) {
              // JWT not expired. Validate JWT
              if (!await isValidJWT(oidcConfig, process.env.ClientId, jwt)) {
                console.error(`Invalid JWT: ${JSON.stringify(cookieMap.id_token)}`);
                response.context.responseOverrideString = JSON.stringify({
                  statusCode: 200,
                  headers: {
                    "Content-type": "text/html"
                  },
                  body: `<!DOCTYPE html><html><body>Session expired. <a href="${getLoginUrl(oidcConfig, process.env.ClientId, redirectUrl)}">Log in again</a>.</body></html>`
                });
                return response;
              }
              // Valid JWT, allow through without response override
              delete response.context.responseOverrideString;
              response.principalId = jwt.payload["sub"];
              return response;
            }
            // If GET method and cookie has valid JWT, allow through without response override
            if (event.httpMethod == "POST" && jwt && isJWTExpired(jwt)) {
              // JWT exists, but expired. Continue to redirect.
              console.log("JWT expired. Redirecting.");
            } else if (event.httpMethod == "POST" && jwt) {
              // JWT not expired. Validate JWT
              if (!await isValidJWT(oidcConfig, process.env.ClientId, jwt)) {
                console.error(`Invalid JWT: ${JSON.stringify(cookieMap.id_token)}`);
                response.context.responseOverrideString = JSON.stringify({
                  statusCode: 200,
                  headers: {
                    "Content-type": "text/html"
                  },
                  body: `<!DOCTYPE html><html><body>Session expired. <a href="${getLoginUrl(oidcConfig, process.env.ClientId, redirectUrl)}">Log in again</a>.</body></html>`
                });
                return response;
              }
              // Valid JWT, allow through without response override
              delete response.context.responseOverrideString;
              response.principalId = jwt.payload["sub"];
              return response;
            }
            // Continue to redirect
            // Everything else, pass response override to Lambda integration to redirect to login page
            response.context.responseOverrideString = JSON.stringify({
              statusCode: 302,
              headers: {
                "Location": getLoginUrl(oidcConfig, process.env.ClientId, redirectUrl)
              }
            });
            return response;
          }
          // Helper function to get HTML that uses AJAX to get tokens from code
          const getInterstitialHTML = function(redirectUrl) {
            return `<!DOCTYPE html>
              <html>
                <head><title>Authenticating...</title></head>
                <body>
                  <h1>Authenticating...</h1>
                  <p>You will be redirected shortly.</p>
                  <p>If you are not redirected automatically, follow <a href="${redirectUrl}">this link</a>.</p>
                  <script>
                    // Helper function for Ajax calls
                    const webRequest = async function(url, opt) {
                      let _XmlHttp;
                      if (window.XMLHttpRequest) {
                        // code for modern browsers
                        _XmlHttp = function() {
                          return new XMLHttpRequest();
                        };
                      } else {
                        // code for old IE browsers
                        _XmlHttp = function() {
                          return new ActiveXObject("Microsoft.XMLHTTP");
                        };
                      }
                      const options = opt ? opt : {};
                      const headers = options.headers ? options.headers : {};
                      return await new Promise(function(resolve, reject) {
                        const xmlHttp = new _XmlHttp();
                        xmlHttp.onreadystatechange = function() {
                          if (this.readyState == 4) {
                            if (this.status === 0) {
                              reject(new Error("Request not sent by browser."));
                            }
                            resolve(this);
                          }
                        };
                        if (typeof options.timeout == "number") {
                          xmlHttp.timeout = options.timeout;
                        }
                        xmlHttp.withCredentials = typeof options.withCredentials == "boolean" ? options.withCredentials : false;
                        xmlHttp.open(options.method ? options.method : "GET", url, true);
                        for (const header in headers) {
                          xmlHttp.setRequestHeader(header, headers[header]);
                        }
                        xmlHttp.send(options.body ? options.body : "");
                      });
                    };
                    // Authenticate using AJAX and save to local storage
                    (async function() {
                      const res = await webRequest(window.location.href, {method: "POST"});
                      if (res.status == 500) {
                        document.body.textContent = res.responseText;
                        return;
                      }
                      if (res.status != 200) {
                        console.error(\`Unexpected response status when getting token: \${res.responseText}\`);
                        return;
                      }
                      const tokens = JSON.parse(res.responseText);
                      if (tokens.error) {
                        console.error(tokens.error);
                        document.body.innerHTML = \`Authentication failed. <a href="\${window.location.protocol}//\${window.location.host}\${window.location.pathname}">Try again</a>.\`;
                        return;
                      }
                      localStorage.setItem("tokens", res.responseText);
                      window.location.href = "${redirectUrl}";
                    })();
                  </script>
                </body>
              </html>`;
          };
          // Helper function to get token from code
          const getTokenFromCode = async function(oidcConfig, clientId, code, redirectUrl) {
            let response = await sendRequest(oidcConfig.token_endpoint, {
              method: "POST",
              headers: {
                "Content-type": "application/x-www-form-urlencoded"
              },
              body: `redirect_uri=${encodeURIComponent(redirectUrl)}&client_id=${encodeURIComponent(clientId)}&code=${encodeURIComponent(code)}&grant_type=authorization_code&code_verifier=${encodeURIComponent(require('crypto').randomUUID())}`
            });
            let data = JSON.parse(response.responseText);
            if (data.error) {
              return data;
            }
            if (!data || !data.id_token || !data.access_token || !data.refresh_token || typeof data.expires_in != "number" || !data.token_type) {
              throw new Error(`Token returned invalid: ${response.responseText}`);
            }
            return data;
          };
          // Helper function get token from refresh token
          const getTokenFromRefreshToken = async function(oidcConfig, clientId, refreshToken, redirectUrl) {
            let response = await sendRequest(oidcConfig.token_endpoint, {
              method: "POST",
              headers: {
                "Content-type": "application/x-www-form-urlencoded"
              },
              body: `redirect_uri=${encodeURIComponent(redirectUrl)}&client_id=${encodeURIComponent(clientId)}&refresh_token=${encodeURIComponent(refreshToken)}&grant_type=refresh_token`
            });
            let data = JSON.parse(response.responseText);
            if (data.error) {
              return data;
            }
            if (!data || !data.id_token || !data.access_token || typeof data.expires_in != "number" || !data.token_type) {
              throw new Error(`Token returned invalid: ${response.responseText}`);
            }
            return data;
          };
          // Helper function to generate a random string and a hash of the random string
          const getFingerprint = function() {
            const raw = require('crypto').randomUUID();
            const hash = hashFingerprintRaw(raw);
            return {raw: raw, hash: hash};
          };
          const hashFingerprintRaw = function(raw) {
            return require('crypto').createHash("sha256").update(raw).digest("hex");
          };
          // Helper function to parse cookies
          const getCookieMapFromValue = function(cookieValue) {
            // Parse cookie
            const cookieArr = typeof cookieValue == "string" ? cookieValue.split(";") : [];
            let cookieMap = {};
            for (const val of cookieArr) {
              const ii = !val ? -1 : val.indexOf("=");
              if (ii == -1) {
                continue;
              }
              cookieMap[val.substr(0, ii).trim()] = val.substr(ii + 1).trim().replace(/(^"|"$)/g, "");
            }
            return cookieMap;
          };
          // Helper function parse JWT
          const parseJWT = function(str) {
            if (typeof str != "string") {
              console.error(`Invalid JWT. Expecting string.`);
              return;
            }
            const parts = str.split(".");
            if (parts.length != 3) {
              console.error(`Invalid JWT. Expecting 3 parts: ${str}`);
              return;
            }
            try {
              const header = JSON.parse(Buffer.from(parts[0], "base64").toString("utf8"));
              const payload = JSON.parse(Buffer.from(parts[1], "base64").toString("utf8"));
              return {
                header: header,
                payload: payload,
                headerBase64: parts[0],
                payloadBase64: parts[1],
                signature: parts[2]
              }
            } catch (e) {
              console.error(`Invalid JWT. Could not parse: ${str}. Error: ${e.message}`);
              return;
            }
          };
          // Helper function to check if expired
          const isJWTExpired = function(jwt, nowTime) {
            const now = typeof nowTime == "number" ? nowTime : Math.floor((new Date()).getTime() / 1000);
            return typeof jwt.payload.exp != "number" || now > jwt.payload.exp;
          };
          // Helper function to validate JWT
          const isValidJWT = async function(oidcConfig, clientId, jwt) {
            if (!jwt || !jwt.header || !jwt.payload || !jwt.signature || !jwt.headerBase64 || !jwt.payloadBase64) {
              console.log("Internal JWT format invalid.");
              return false;
            }
            if (jwt.payload.aud != clientId) {
              console.log(`Audience (${jwt.payload.aud}) does not match client ID (${clientId}).`);
              return false;
            }
            const now = Math.floor((new Date()).getTime() / 1000);
            if (isJWTExpired(jwt, now)) {
              console.log(`Expiration (${JSON.stringify(jwt.payload.exp)}) invalid or has passed (current: ${now}).`);
              return false;
            }
            const jwk = await getJWKFromJWKSEndpoint(oidcConfig.jwks_uri, jwt.header.kid);
            if (!jwk) {
              throw new Error("Unable to retrieve JWK.");
            }
            return verifyJWKSignature(`${jwt.headerBase64}.${jwt.payloadBase64}`, jwk, jwt.signature);
          };
          // Helper function to retrieve and find matching key ID from JWKS
          const getJWKFromJWKSEndpoint = async function(jwks_uri, kid) {
            const res = await sendRequest(jwks_uri);
            const data = JSON.parse(res.responseText);
            for (const key of data.keys) {
              if (key.kid == kid) {
                return key;
              }
            }
          };
          // Helper to verify signature
          const verifyJWKSignature = function(data, jwk, signature) {
            const crypto = require("crypto");
            const publicKey = crypto.createPublicKey({key: {n: jwk.n, e: jwk.e, kty: jwk.kty}, format: "jwk"});
            const signatureBuffer = Buffer.from(signature, "base64");
            const verify = crypto.createVerify("SHA256");
            verify.update(data);
            verify.end();
            return verify.verify(publicKey, signatureBuffer);
          };
          // Helper function to get loginUrl
          const getLoginUrl = function(oidcConfig, clientId, redirectUrl) {
            return `${oidcConfig.authorization_endpoint}?client_id=${encodeURIComponent(clientId)}&response_type=code&scope=openid&redirect_uri=${encodeURIComponent(redirectUrl)}`
          };
          // Helper function to make web request
          const sendRequest = async function(url, opt) {
            opt = opt ? opt : {};
            const parsedUrl = require("url").parse(url);
            let headers = opt.headers ? opt.headers : {};
            headers["Content-length"] = opt.body ? opt.body.length : 0;
            const options = {
              hostname: parsedUrl.hostname,
              port: opt.port ? opt.port : (parsedUrl.protocol == "https:" ? 443 : 80),
              path: parsedUrl.path,
              method: opt.method ? opt.method : "GET",
              headers: headers
            };
            let response = await new Promise(function(res, err) {
              let request = require(parsedUrl.protocol == "https:" ? "https" : "http").request(options, function(response) {
                let responseText = [];
                response.on("data", function(d) {
                  responseText.push(d);
                });
                response.on("end", function() {
                  response.responseText = responseText.join("");
                  res(response);
                });
              });
              request.on("error", function(error) {
                console.error("sendRequest Error: " + error);
                err(error);
              });
              request.write(opt.body ? opt.body : "");
              request.end();
            });
            return response;
          };