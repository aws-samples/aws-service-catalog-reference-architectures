import boto3
import os
import json
import botocore
import textwrap

 
_region = os.environ['AWS_REGION']
s3_client  = boto3.client('s3', _region, config=botocore.config.Config(s3={'addressing_style':'virtual'}))
def lambda_handler(event, context):
    print(json.dumps(event))

    bucket = os.environ['bdbucket']
    
    co ="Content-Type"
    prefix ="content/holding/uploads/"
    if 'prefix' in event['queryStringParameters']:
        prefix = event['queryStringParameters']['prefix']
        
    if 'Content-Type' in event['queryStringParameters']:
        Content_Type = event['queryStringParameters']['Content-Type']


    
    form_data = s3_client.generate_presigned_post(
        Bucket=bucket,
        Key=r'${filename}',
        Conditions = [  {"acl": "private"}, {'Content-Type':Content_Type}],
        ExpiresIn=3600)
        
    _key=form_data['fields']['key']
    form_data['fields']['key'] =f'{prefix}{_key}'
    input_fields = "\n".join(
        f'<input type="hidden" name="{k}" value="{v}" />'
        for k, v in form_data['fields'].items())

   
    print(json.dumps(form_data))

    ctype= "application/json"
    response = {
                            "statusCode": 200,
                            "isBase64Encoded": False,
                            "body": json.dumps(form_data),
                            "headers": {
                                'Content-Type': ctype,
                                'Access-Control-Allow-Origin': '*'
                            }}
    return response