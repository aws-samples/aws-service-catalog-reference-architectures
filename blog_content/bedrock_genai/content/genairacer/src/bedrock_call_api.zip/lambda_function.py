import json
import os
import boto3
import random
import string
import logging
import time
import uuid
import base64
import botocore
from botocore.exceptions import ClientError
from datetime import datetime, timedelta
from botocore.client import Config

import logging

# Configure logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # or logging.DEBUG for more detailed logs


bedclient = boto3.client('bedrock')
bedrock_runtime =  boto3.client('bedrock-runtime', region_name="us-east-1")

s3 = boto3.resource('s3')
s3_client = boto3.client('s3')#, config=Config(signature_version='s3v4'))

bedrun = boto3.client('bedrock-runtime',region_name='us-east-1')

def bed_getmodels(modelIdentifier):
    resp  = bedclient.get_foundation_model(modelIdentifier=modelIdentifier)['modelDetails']
    #GetFoundationModelAvailability
    return resp
    
def bed_listmodels(event):
    _ar=0
    resp = bedclient.list_foundation_models()['modelSummaries']
    
    bucket= event['bucket']
    modelId = event['modelid']
    fmlistkey = f"{event['prefix']}data/fmlist.json"
    bucket_putpriv(bucket, fmlistkey, json.dumps(resp,indent=2),"text/json")
    return resp

def bucket_get_obj(bucket, bkey):
    object = s3_client.get_object(Bucket=bucket, Key=bkey)
    return(object['Body'].read().decode('utf-8'))
def bucket_putpriv(bucket, key, body,type):
    srep = s3_client.put_object(
        ACL='private', Body=body, Bucket=bucket, Key=key, ContentType=type,)
    #print(srep)
    return srep    
def gen_surl(bucketname, keyname):
    url = s3_client.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucketname, 'Key': keyname})
    return url
def bucket_key_exist(bucket,key):
    _ret=True
    try:
        rep = s3_client.get_object(Bucket=bucket, Key=key)
    except botocore.exceptions.ClientError as e:
        print(e.response['Error']['Code'])
        _ret= False
        if e.response['Error']['Code'] == "404":
            print(e.response['Error']['Code'])
            _ret= False
            
        else:
            # Something else has gone wrong.
            print(e.response['Error']['Code'])
    return _ret
#######################
#
#

#
def bed_invoke_claude_message(event):
    _ret =""
    try:

     
        system_prompt = "hello"
        max_tokens = 2000

        # Prompt with user turn only.
        user_message =  {"role": "user", "content": event['prompt']}

        assistant_message =  {"role": "assistant", "content": ""}
        messages = [user_message, assistant_message]
        response = generate_message(bedrun, event['modelid'],system_prompt, messages, max_tokens)
        _ret = response['content'][0]['text']

    except ClientError as err:
        message=err.response["Error"]["Message"]
        logger.error("A client error occurred: %s", message)
        print("A client error occured: " +
            format(message))
    return _ret
def bed_invoke_nova(event):
    
    body = {
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "text": event['prompt']
                    }
                ]
            }
        ],
        "inferenceConfig": {
            "max_new_tokens": 8800,
            "temperature": 0.7,
            "top_p": 0.9,
            "top_k": 50
        }
    }

    response = bedrun.invoke_model(
        modelId=event['modelid'],
        contentType='application/json',
        accept='application/json',
        body=json.dumps(body)
        )
    response_body = json.loads(response['body'].read())
    return response_body['output']['message']['content'][0]['text']
def bed_invoke_canvas(prompt, model_id, bucket, prefix,event):
    _ret=[]
    _images=[]
    dseed  = random.randint(1230, 24200)
    nprompt = shorten_prompt(prompt)
    
    request_body = {
            "imageGenerationConfig":
            {
                "cfgScale": 6.5,
                "height": 720,
                "numberOfImages": 1,
                "seed": dseed,
                "width": 1280
            },
            "taskType": "TEXT_IMAGE",
            "textToImageParams":
            {
                "text": nprompt
            }
        }
    

    response = bedrock_runtime.invoke_model(
        body=json.dumps(request_body),
        modelId=model_id,
        contentType='application/json',
        accept='application/json'
    )
    time.sleep(3)
    
    response_body = json.loads(response['body'].read())

    if 'images' in response_body:
        for _img in response_body['images']:
            dakey = generate_random_png_filename(prefix=prefix, length=10)
            image_data = base64.b64decode(_img)
            bucket_putpriv(bucket, dakey, image_data,'image/png')
            img = {'skey':gen_surl(bucket,dakey)}
            _ret.append(gen_surl(bucket,dakey))

    _rndstring = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    
    timestamp = datetime.utcnow().isoformat()
    event['images'] = _ret
    return _ret
def generate_message(bedrun, model_id, system_prompt, messages, max_tokens):

    body=json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": messages
        }  
    )  

    
    response =bedrun.invoke_model(body=body, modelId=model_id)
    response_body = json.loads(response.get('body').read())
   
    return response_body    

#
def shorten_prompt(prompt):
    if len(prompt) > 1023:
        return prompt[:1020] + "..."
    return prompt
def generate_random_mp4_filename(prefix="video_", length=8):
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    unique_id = uuid.uuid4().hex[:8]
    return f"{prefix}{random_string}_{unique_id}.mp4"
def generate_random_png_filename(prefix="image_", length=8):
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    unique_id = uuid.uuid4().hex[:8]
    return f"{prefix}{random_string}_{unique_id}.png"
    
def lambda_handler(event, context):
    # TODO implement
    #
    rbody={}
    print(json.dumps(event))

    
    if 'body' in event:
        mevent = json.loads(event['body'])
    else:
        mevent=event

    bucket = os.environ['bucket']
    prefix = os.environ['prefix']
    imgprefix = os.environ['imgprefix']  
    
    mevent['bucket'] = bucket
    mevent['prefix'] = prefix
    mevent['imgprefix'] = imgprefix
 
    print(json.dumps(mevent))
    
    
    if 'actiontype' not in mevent:
        return {
            'statusCode': 200,
            "headers": {'Content-Type': 'text/html','Access-Control-Allow-Origin': '*'},
            'message':  "no action"
        }

   
    
    if mevent['actiontype'] ==  'text':
        rtext = "hello world"
        if mevent['guardrailToggle'] == "On":
            g_det = mevent['guardrail'].split("||")
            apply_guardrail_response = bedrock_runtime.apply_guardrail(
                guardrailIdentifier=g_det[0],
                guardrailVersion=g_det[1],
                source= 'INPUT',
                content=[{"text": {"text": mevent['prompt']}}]
                )
            if apply_guardrail_response['action'] == "GUARDRAIL_INTERVENED":
                rtext = apply_guardrail_response['outputs'][0]['text']
            else:
                if mevent['modelid'].find('amazon.nova') > -1:
                    rtext= bed_invoke_nova(mevent)
                if mevent['modelid'].find('anthropic.claude') > -1:
                    rtext = bed_invoke_claude_message(mevent)
                apply_guardrail_response = bedrock_runtime.apply_guardrail(
                    guardrailIdentifier=g_det[0],
                    guardrailVersion=g_det[1],
                    source= 'OUTPUT',
                    content=[{"text": {"text": rtext}}]
                    )
                if apply_guardrail_response['action'] == "GUARDRAIL_INTERVENED":
                    rtext = apply_guardrail_response['outputs'][0]['text']
                
        else:
                if mevent['modelid'].find('amazon.nova') > -1:
                    rtext= bed_invoke_nova(mevent)
                if mevent['modelid'].find('anthropic.claude') > -1:
                    rtext = bed_invoke_claude_message(mevent)

            
        _ret = {
                "statusCode": 200,
                "isBase64Encoded": False,
                "body":json.dumps({"returntext":rtext}),
                "headers": {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }}
        return _ret
