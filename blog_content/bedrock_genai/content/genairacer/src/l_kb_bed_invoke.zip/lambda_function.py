import boto3
import json



def invoke_bedrock_knowledge_base(event):
    # Create a Bedrock Agent Runtime client
    client = boto3.client('bedrock-agent-runtime', region_name='us-east-1')  # Replace with your region

    try:
        # Prepare the request
        request = {
            'input': {
                'text': event['query']
            },
            'retrieveAndGenerateConfiguration': {
                'type': 'KNOWLEDGE_BASE',
                'knowledgeBaseConfiguration': {
                    'knowledgeBaseId': event['knowledge_base_id'],
                    'modelArn': event['model_arn']
                }
            }
        }

        # Make the API call
        response = client.retrieve_and_generate(**request)

        # Extract and return the generated text
        return response['output']['text']

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

def lambda_handler(event, context):
    print(json.dumps(event))
    bbody = json.loads(event['body'])
    print(json.dumps(bbody))
    result = invoke_bedrock_knowledge_base(bbody)
    
    if result:
        return {
            'statusCode': 200,
            "isBase64Encoded": False,
            "headers": {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body':  json.dumps(result)}
