import json
import os

import boto3
import random
import time
import uuid
import base64
import botocore
from botocore.client import Config

import datetime


class DateEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        return json.JSONEncoder.default(self, obj)




s3 = boto3.resource('s3')
s3_client = boto3.client('s3')#, config=Config(signature_version='s3v4'))
bedrock = boto3.client('bedrock')



def bucket_get_obj(bucket, bkey):
    object = s3_client.get_object(Bucket=bucket, Key=bkey)
    return(object['Body'].read().decode('utf-8'))
def bucket_putpriv(bucket, key, body,type):
    srep = s3_client.put_object(
        ACL='private', Body=body, Bucket=bucket, Key=key, ContentType=type,)
    #print(srep)
    return srep    
def gen_surl(bucketname, keyname):
    url = s3_client.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucketname, 'Key': keyname})
    return url
def bucket_key_exist(bucket,key):
    _ret=True
    try:
        rep = s3_client.get_object(Bucket=bucket, Key=key)
    except botocore.exceptions.ClientError as e:
        print(e.response['Error']['Code'])
        _ret= False
        if e.response['Error']['Code'] == "404":
            print(e.response['Error']['Code'])
            _ret= False
            
        else:
            # Something else has gone wrong.
            print(e.response['Error']['Code'])
    return _ret
def update_s3html(shtmls):
    for rr in shtmls:
        content = bucket_get_obj(shtmls[rr]['bucket'],shtmls[rr]['sourcekey'])
        for _rep in shtmls[rr]['replacments']:
            _repa=_rep.split('--')
            content = content.replace(_repa[0],_repa[1])
        bucket_putpriv(shtmls[rr]['bucket'],shtmls[rr]['key'],content,'text/html')
    return 1
def get_bdf_info():
    bedrock = boto3.client('bedrock')
    
    flist =bedrock.list_foundation_models()['modelSummaries']
    return flist
    
def get_kb_info():
    bedrock_client = boto3.client('bedrock-agent')
    knowledge_bases=[]
    
    try:
        # Call the list_knowledge_bases API
        response = bedrock_client.list_knowledge_bases()
        print(response)

        knowledge_bases = response.get('knowledgeBaseSummaries', [])
        
        
    except Exception as e:
        print(f"Error: {str(e)}")
    
    ret  = json.loads(json.dumps(knowledge_bases, cls=DateEncoder))
    knowledge_base_id_value=''
    for dval in ret:
        if dval['name'].find('CFTKnowbase') > -1:
            knowledge_base_id_value = dval['knowledgeBaseId']
            
    return knowledge_base_id_value

#######
def list_guardrails(max_results=None, next_token=None):
   
    params = {}
    _gr=[]
    if max_results:
        params['maxResults'] = max_results
    if next_token:
        params['nextToken'] = next_token
    
    try:
        response = bedrock.list_guardrails(**params)
        
        guardrails = response.get('guardrails', [])
        next_token = response.get('nextToken')
        for gg in guardrails:
            _g = {"guardrailIdentifier":gg["arn"],"guardrailVersion":gg['version'],"name":gg['name']}
            _gr.append(_g)
        
        return _gr
    
    except Exception as e:
        print(f"Error listing guardrails: {str(e)}")
        return []

#import boto3
#

def check_bedrock_access():
    bedrock = boto3.client('bedrock')
    from botocore.exceptions import ClientError
    
    try:
        # List available foundation models (doesn't verify access)
        response = bedrock.list_foundation_models()
        print("Available models in your region:")
        tm =[]
        for model in response['modelSummaries']:
            if 'nova' in model['modelId'] or 'claude' in model['modelId']:
                tm.append(model['modelId'])
                print(f"- {model['modelId']} (Status: {model.get('modelLifecycle', {}).get('status', 'UNKNOWN')})")
            
        
        # Attempt to invoke a model (real access check)
        for test_model in tm:
            #test_model = "anthropic.claude-v2"  # Replace with your target model
            bedrock.get_foundation_model(modelIdentifier=test_model)
            print(f"\n✅ Confirmed access to {test_model}")
        return True
        
    except ClientError as e:
        if "AccessDeniedException" in str(e):
            print("❌ Missing bedrock:GetFoundationModel permission")
            print(str(e))
        elif "ResourceNotFoundException" in str(e):
            print(f"❌ No access to model {test_model} - request access in AWS Console")
        else:
            print(f"❌ Unexpected error: {e}")
        return False

# Usage



def lambda_handler(event, context):
    # TODO implement
    #
    _html=''
    print(json.dumps(event))
    
    # If Lambda Custom Authorizer provides a response override, return response and stop
    if ('requestContext' in event and 'authorizer' in event['requestContext'] and 
        'responseOverrideString' in event['requestContext']['authorizer']):
        return json.loads(event['requestContext']['authorizer']['responseOverrideString'])

    knowledge_base_id_value = os.environ['KnowledgeBaseId']
    #eturn knowledge_base_id_value
    grails= list_guardrails(max_results=10)
    
    #return get_bdf_info()
    print('subsituting streaming ....')



    _gselect = '<select id="guardrail" class="fancy-select"> <option value="" disabled selected>Choose a Guardrail</option>'
    for gs in grails:
        _gselect += f"<option value='{gs['guardrailIdentifier']}||{gs['guardrailVersion']}'> {gs['name']}</option>"
    
    _gselect += '</select>' 
    #return _gselect
 
    #json.loads(json.dumps(_ret, cls=DateEncoder))
 

    bucket = os.environ['bucket']
    prefix = os.environ['prefix']
    guardrailurl = os.environ['guardrailurl']
    imgprefix = os.environ['imgprefix']  
    apigw = os.environ['apigw']
    pollyapigw= os.environ['pollyapigw']
    print("yo"+pollyapigw)
    #common
    tbstylekey=f"{prefix}web/css/tbstyle.css"
    gtbstylekey= gen_surl(bucket,tbstylekey)
    
    
    ####kb###
    llmkey =f"{prefix}data/mpllm.json"
    kb_modelarn = json.loads(bucket_get_obj(bucket,llmkey))['modelarn']
    print(kb_modelarn)
    sel_kbtext=[] 
    
    for _sel in kb_modelarn:
        _s = f"{_sel['modelName']}=={_sel['modelId']}"
        sel_kbtext.append(_s)
    
    text_bed_kb_o    =f"{prefix}web/text_bed_kb_o.html"
    text_bed_kb_out  =f"{prefix}web/out/text_bed_kb.html" 
    
    surl_text_bed_kb_out = gen_surl(bucket,text_bed_kb_out)
    
    reps=[]
    kbinvoke  = os.environ['kbinvoke']
    kblistdoc = os.environ['kblistdoc']
    kbupload =  os.environ['kbupload']
    
    rep1 = f"kbinvoke--{kbinvoke}"
    rep2 = f"kblistdoc--{kblistdoc}"
    rep3 = f'tbstyle.css--{gtbstylekey}'
    rep4 = f'"___textkbmodel___"--{sel_kbtext}'
    rep5 = f'__knowledge_base_id__--{knowledge_base_id_value}'
    rep6 = f'-uploadurl--{kbupload}'
    
    reps.append(rep1)
    reps.append(rep2)
    reps.append(rep3)
    reps.append(rep4)
    reps.append(rep5)
    reps.append(rep6)
    
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':text_bed_kb_o,'key':text_bed_kb_out,'replacments':reps}}
    update_s3html(s3updates) 
    ####
        
    mainwebpage =f"{prefix}web/awsgenai.html"
    mainpageorg =f"{prefix}web/awsgenai_org.html"
    #return mainpageorg
    
    ####
    ###
    llmkey =f"{prefix}data/mpllm.json"
    llmjson = json.loads(bucket_get_obj(bucket,llmkey))['subscribed']
    sel_text=[]
    
    sel_image=[]
    
    
    
    for _sel in llmjson:
        _s = f"{_sel['modelName']}=={_sel['modelId']}"
        if _sel['type'] == "text":
            sel_text.append(_s)
        if _sel['type'] == "image":
            sel_image.append(_s)
        

    tpage  = str(random.randint(1230, 24200)) 
    imagewebpage =f"{prefix}web/out/sm_image_{tpage}.html"
    imagewebpage_o =f"{prefix}web/sm_image_o.html"

    #https://0arfvtkq16.execute-api.us-east-1.amazonaws.com/mygpt/canvas
    canvasurl= f"{apigw}canvas"
    #canvasurl= "https://0arfvtkq16.execute-api.us-east-1.amazonaws.com/mygpt/canvas"
    print(canvasurl)
    reps=[]
    rapigw = f"apigwmygpt--{canvasurl}"
    reps.append(rapigw)
    rtllm= f"___imagellm___--{sel_image}"
    reps.append(rtllm)
    s3updates = {'grud':{'bucket':bucket,'sourcekey':imagewebpage_o,'key':imagewebpage,'replacments':reps}}
    update_s3html(s3updates)  
    surlbedrock=gen_surl(bucket,imagewebpage)
    ###
    
    
    #######
    guard_source =f"{prefix}web/sm_guardrail_o.html"
    guard_dest   =f"{prefix}web/out/sm_guardrail.html"
    rep=[]

    rep1 = f"__guardrailurl___--{guardrailurl}"
    reps.append(rep1)
    s3updates = {'grud':{'bucket':bucket,'sourcekey':guard_source,'key':guard_dest,'replacments':reps}}
    update_s3html(s3updates)  
    g_guard_page=gen_surl(bucket,guard_dest)
    #####
    


    
    
    
    textpage =f"{prefix}web/text.html"
    textpage_o =f"{prefix}web/text_o.html"
    surltextpage=gen_surl(bucket,textpage)
    rep2 = f"text.html--{surltextpage}"
    reps.append(rep2)
    
    audio_page   =f"{prefix}web/sm_audio.html"
    audio_page_o =f"{prefix}web/sm_audio_o.html"
    g_audio_page=gen_surl(bucket,audio_page)
    rep2 = f"apigwaudio--{surltextpage}"
    reps.append(rep2)
    rep3 = f"text_bed_kb_o.html--{surl_text_bed_kb_out}"
    reps.append(rep3)
    repaud = f"sm_audio.html--{g_audio_page}"
    reps.append(repaud)
    newimagerep    = f"sm_image_o.html--{surlbedrock}"
    reps.append(newimagerep)
    
    guardrep    = f"sm_guardrail_o.html--{g_guard_page}"
    reps.append(guardrep)
    
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':mainpageorg,'key':mainwebpage,'replacments':reps}}
    update_s3html(s3updates)    
    #
    reps=[]
    newapi =f"{apigw}mpcatmgt"
    rapigw = f"apigwmygpt--{newapi}"
    reps.append(rapigw)
    rtllm= f"___textllm___--{sel_text}"
    reps.append(rtllm)
 
    
    tbstylekey=f"{prefix}web/css/tbstyle.css"
    gtbstylekey= gen_surl(bucket,tbstylekey)
    gtb=f"tbstyle.css--{gtbstylekey}"
    reps.append(gtb)
    
    grupd = f"__gselect__--{_gselect}"
    reps.append(grupd)
    
    
 
    
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':textpage_o,'key':textpage,'replacments':reps}}
    update_s3html(s3updates)

    ##--polly
    #
    reps=[]
    
    rapigw = f"apigwaudio--{pollyapigw}"
    reps.append(rapigw)

    
    runbutkey =f"{prefix}web/images/run.svg"
    grunbutkey = gen_surl(bucket,runbutkey)
    rgg=f"images/run.svg--{grunbutkey}"
    reps.append(rgg)
    
    
    tbstylekey=f"{prefix}web/css/tbstyle.css"
    gtbstylekey= gen_surl(bucket,tbstylekey)
    gtb=f"tbstyle.css--{gtbstylekey}"
    reps.append(gtb)
    
    clbutkey=f"{prefix}web/images/clearButton.svg"
    gclbutkey = gen_surl(bucket,clbutkey)
    rpgc =f"images/clearButton.svg--{gclbutkey}"
    reps.append(rpgc)

 
    pollykey_o =f"{prefix}web/sm_audio_o.html"
    pollykey =f"{prefix}web/sm_audio.html"
    
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':pollykey_o,'key':pollykey,'replacments':reps}}
    update_s3html(s3updates)
    ##
    _rhtml = bucket_get_obj(bucket,mainwebpage)
    ctype='text/html'
    response = {
                            "statusCode": 200,
                            "body": _rhtml,
                           
                
                            "headers": {
                                'Content-Type': ctype,
                                'Access-Control-Allow-Origin': '*'
                            }}
    return response