import os
import json
import boto3
import random
import time
import botocore
import urllib3
http = urllib3.PoolManager()
s3client    = boto3.client('s3')

#
_region = os.environ['AWS_REGION']
s3client  = boto3.client('s3', _region, config=botocore.config.Config(s3={'addressing_style':'path'}))


polly_client = boto3.client('polly')
 
 
def s3getlist(bucket,Prefix):
    res  = s3client.list_objects_v2(Bucket=bucket,  Prefix=Prefix)
    key=[]
    if 'Contents' in res:
        for _content in res['Contents']:
            if _content['Key'].find('metadata') > -1:
                d= 0
            else:
                key.append(_content['Key'])
    return key
    
def gen_surl(bucketname, keyname):
    url = s3client.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucketname, 'Key': keyname})
    return url
    
def bucket_putpriv_v1(bucket, key,  acl):
    srep = s3client.put_object_acl(ACL=acl, Bucket=bucket, Key=key)
    return srep
    
def bucket_putpriv(bucket, key, body,type):
    srep = s3client.put_object(
        ACL='private', Body=body, Bucket=bucket, Key=key, ContentType=type,)
    print(srep)
    return srep
    
def bucket_get_obj(bucket, bkey):
    object = s3client.get_object(Bucket=bucket, Key=bkey)
    return(object['Body'].read().decode('utf-8'))

def pollystartspeech(bucket,prefix,text,voice):
    rep = polly_client.start_speech_synthesis_task(Engine='standard',OutputFormat= 'mp3',OutputS3BucketName=bucket,OutputS3KeyPrefix=prefix,Text=text,
           VoiceId=voice)
    return rep['SynthesisTask']['OutputUri']
    
 
        
def lambda_handler(event, context):
    # TODO implement
    print(json.dumps(event)) 
    
    
    bucket = os.environ['bucket']
    prefix = os.environ['prefix']
    
    prefixout = f"{prefix}/web/audio/out/polly/"
    
    
    #
    _voices= ["Joanna","Matthew"]
    voice = random.choice(_voices)
    #
    
    text   = event['text_prompt']
    texurl = text[0:18].replace(' ','_')
    event['texurl'] = texurl
    
    outuri = pollystartspeech(bucket,prefixout,text,voice)
    bbucket = f"{bucket}/"
    outurlA= outuri.split(bbucket)[1]
    outuri_surl = gen_surl(bucket,outurlA)
    event['audio_file'] = outuri_surl
    
    print(json.dumps(event)) 
    time.sleep(5)
                        
    return {
        'statusCode': 200,
        'headers': {'ContentType':'text/html','Access-Control-Allow-Origin': '*'},
        'contentType':'text/html',
        'audiourl':texurl,
        'audio_file': outuri_surl
    }
