import json
import os
import boto3
import random
import string
import logging
import time
import uuid
import base64
import botocore
from botocore.exceptions import ClientError
from datetime import datetime, timedelta
from botocore.client import Config

import logging

# Configure logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # or logging.DEBUG for more detailed logs


bedclient = boto3.client('bedrock')
bedrock_runtime =  boto3.client('bedrock-runtime', region_name="us-east-1")

s3 = boto3.resource('s3')
s3_client = boto3.client('s3')#, config=Config(signature_version='s3v4'))

bedrun = boto3.client('bedrock-runtime',region_name='us-east-1')


def bucket_get_obj(bucket, bkey):
    object = s3_client.get_object(Bucket=bucket, Key=bkey)
    return(object['Body'].read().decode('utf-8'))
def bucket_putpriv(bucket, key, body,type):
    srep = s3_client.put_object(
        ACL='private', Body=body, Bucket=bucket, Key=key, ContentType=type,)
    #print(srep)
    return srep    
def gen_surl(bucketname, keyname):
    url = s3_client.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucketname, 'Key': keyname})
    return url
def bucket_key_exist(bucket,key):
    _ret=True
    try:
        rep = s3_client.get_object(Bucket=bucket, Key=key)
    except botocore.exceptions.ClientError as e:
        print(e.response['Error']['Code'])
        _ret= False
        if e.response['Error']['Code'] == "404":
            print(e.response['Error']['Code'])
            _ret= False
            
        else:
            # Something else has gone wrong.
            print(e.response['Error']['Code'])
    return _ret
#######################


def generate_random_mp4_filename(prefix="video_", length=8):
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    unique_id = uuid.uuid4().hex[:8]
    return f"{prefix}{random_string}_{unique_id}.mp4"
def generate_random_png_filename(prefix="image_", length=8):
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    unique_id = uuid.uuid4().hex[:8]
    return f"{prefix}{random_string}_{unique_id}.png"
##
def abed_invoke_canvas(prompt, model_id, bucket, prefix,event):
    _ret=[]
    _images=[]
    dseed  = random.randint(1230, 24200)
    nprompt = prompt[:1000] + " " +event['pstyle'] 
    
    request_body = {
            "imageGenerationConfig":
            {
                "cfgScale": 6.5,
                "height": 720,
                "numberOfImages": 2,
                "seed": dseed,
                "width": 1280
            },
            "taskType": "TEXT_IMAGE",
            "textToImageParams":
            {
                "text": nprompt
            }
        }
    

    response = bedrock_runtime.invoke_model(
        body=json.dumps(request_body),
        modelId=model_id,
        contentType='application/json',
        accept='application/json'
    )
    time.sleep(3)
    print(response)
    
    response_body = json.loads(response['body'].read())

    if 'images' in response_body:
        for _img in response_body['images']:
            dakey = generate_random_png_filename(prefix=prefix, length=10)
            image_data = base64.b64decode(_img)
            bucket_putpriv(bucket, dakey, image_data,'image/png')
            img = {'skey':gen_surl(bucket,dakey)}
            _ret.append(gen_surl(bucket,dakey))

    _rndstring = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    
    timestamp = datetime.utcnow().isoformat()
    event['images'] = _ret
    return _ret
def bed_invoke_canvas(prompt, model_id, bucket, prefix, event):
    _ret = []
    _images = []
    dseed = random.randint(1230, 24200)
    nprompt = prompt[:1000] + " " + event['pstyle']

    request_body = {
        "imageGenerationConfig": {
            "cfgScale": 6.5,
            "height": 720,
            "numberOfImages": 2,
            "seed": dseed,
            "width": 1280
        },
        "taskType": "TEXT_IMAGE",
        "textToImageParams": {
            "text": nprompt
        }
    }

    try:
        response = bedrock_runtime.invoke_model(
            body=json.dumps(request_body),
            modelId=model_id,
            contentType='application/json',
            accept='application/json'
        )
        time.sleep(3)
        print(response)

        response_body = json.loads(response['body'].read())

        if 'images' in response_body:
            for _img in response_body['images']:
                dakey = generate_random_png_filename(prefix=prefix, length=10)
                image_data = base64.b64decode(_img)
                bucket_putpriv(bucket, dakey, image_data, 'image/png')
                img = {'skey': gen_surl(bucket, dakey)}
                _ret.append(gen_surl(bucket, dakey))

        _rndstring = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
        timestamp = datetime.utcnow().isoformat()
        event['images'] = _ret
        return _ret

    except Exception as e:
        # Check for ValidationException and the specific error message
        if hasattr(e, 'response'):
            error_response = getattr(e, 'response')
            error_message = error_response.get('Error', {}).get('Message', str(e))
            error_type = error_response.get('Error', {}).get('Code', '')
        else:
            error_message = str(e)
            error_type = getattr(e, 'errorType', '')

        if error_type == 'ValidationException' and "request has been blocked by our content filters" in error_message:
            print("Content filter triggered:", error_message)
            # Handle blocked prompt: return an empty list, set an error in event, etc.
            event['error'] = "Blocked by content filters"
            return []
        else:
            # Re-raise unexpected errors
            raise

##
def lambda_handler(event, context):
    # TODO implement
    #
    rbody={}
    #print(json.dumps(event))

    
    if 'body' in event:
        mevent = json.loads(event['body'])
    else:
        mevent=event

    bucket = os.environ['bucket']
    prefix = os.environ['prefix']
    imgprefix = os.environ['imgprefix']  
    
    mevent['bucket'] = bucket
    mevent['prefix'] = prefix
    mevent['imgprefix'] = imgprefix
    
 
    #print(json.dumps(mevent))
    
    
    if 'actiontype' not in mevent:
        return {
            'statusCode': 200,
            "headers": {'Content-Type': 'text/html','Access-Control-Allow-Origin': '*'},
            'message':  "no action"
        }


    if mevent['actiontype'] ==  'image':
        
        _ret = bed_invoke_canvas(mevent['text_prompt'], mevent['modelid'], mevent['bucket'],mevent['imgprefix'],mevent)

        _rret = {
                "statusCode": 200,
                "isBase64Encoded": False,
                "body":json.dumps({"image_url":_ret}),
                
                "headers": {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }} 
      
        return _rret

