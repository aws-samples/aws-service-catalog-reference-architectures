import os
import json
import base64
import botocore
import boto3
import random





_region = os.environ['AWS_REGION']
s3_client  = boto3.client('s3', _region, config=botocore.config.Config(s3={'addressing_style':'virtual'}))

def s3_listobj(bucket,prefix):
    response = s3_client.list_objects_v2(
    Bucket=bucket,
    Delimiter=',',
    EncodingType='url',
    Prefix=prefix)
    _ret=[]
    if 'Contents' in response:
        for fkey in response['Contents']:
            if fkey['Key'].find(".") > -1:
                _ret.append(fkey['Key'] )
    
    return  _ret



def bucket_get_obj(bucket, bkey):
    object = s3_client.get_object(Bucket=bucket, Key=bkey)
    return(object['Body'].read().decode('utf-8'))
def bucket_putpriv(bucket, key, body,type):
    srep = s3_client.put_object(
        ACL='private', Body=body, Bucket=bucket, Key=key, ContentType=type,)
    #print(srep)
    return srep    
def gen_surl(bucketname, keyname):
    url = s3_client.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucketname, 'Key': keyname})
    return url
def bucket_key_exist(bucket,key):
    _ret=True
    try:
        rep = s3_client.get_object(Bucket=bucket, Key=key)
    except botocore.exceptions.ClientError as e:
        print(e.response['Error']['Code'])
        _ret= False
        if e.response['Error']['Code'] == "404":
            print(e.response['Error']['Code'])
            _ret= False
            
        else:
            # Something else has gone wrong.
            print(e.response['Error']['Code'])
    return _ret


def lambda_handler(event, context):
    print(json.dumps(event))
    _rand  = random.randint(10, 24200)
    bucket='aceapibeta27525'
    bucket = os.environ['bdbucket']
    if 'prefix' in event['queryStringParameters'] :
        prefix = event['queryStringParameters']['prefix']
    else:
        prefix = "uploads/"
    _html = s3_listobj(bucket,prefix)
    #return _html
    
    ctype='application/json'
    
    response = {
                            "statusCode": 200,
                             "isBase64Encoded": False,
                            "body": json.dumps(_html),
                             "headers": {
                                'Content-Type': ctype,
                                'Access-Control-Allow-Origin': '*'
                            }}
    return response