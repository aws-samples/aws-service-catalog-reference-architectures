import json
import logging
import random
import urllib3
import threading
import boto3

sc_client = boto3.client('servicecatalog')
s3client = boto3.client('s3')
ssmclient = boto3.client('ssm')

http = urllib3.PoolManager()
logger = logging.getLogger()

  
def get_ssm_para(name) :
  response = ssmclient.get_parameter(Name=name)
  return(response['Parameter']['Value'])
  
def put_ssm_para(name,value) :
  response = ssmclient.put_parameter(Name= name, Description='Description '+name,    Value=value,Type='String')
  return 7

def del_ssm_para(name):
  response = ssmclient.delete_parameter(Name=name)
  return 'ok'

def b_put(bucket, key, body):
    srep = s3client.put_object(
        Body=body, Bucket=bucket, Key=key, ContentType='text/json',)
    return srep

def b_get_obj(event, bkey):
    object = s3client.get_object(
        Bucket=event['bucket'], Key=bkey)
    return object['Body'].read().decode('utf-8')

def desc_doc(dname):
    response = ssmclient.describe_document(Name=dname)
    _ret = {"Name": response['Document']['Name'], "version": response['Document']\
            ['VersionName'], "Status": response['Document']['Status']}
    return _ret


def cr_ssmdoc(event):
    bevent = {}
    bevent['bucket'] = event['ResourceProperties']['svc_action_bucket']
    prefix = event['ResourceProperties']['svc_action_prefix']
    bkey = event['ResourceProperties']['svc_action_key']
    key = f'{prefix}{bkey}'
    #return key
    TargetType = event['ResourceProperties']['TargetType']
    c_onten = json.loads(b_get_obj(bevent, key))
    #c_onten['parameters']['AutomationAssumeRole']['default'] = event['ResourceProperties']['svc_action_role']
    c_onten['assumeRole']  = event['ResourceProperties']['svc_action_role']
    
    _rand = str(random.randint(134324, 12342400))
    Name = f'sc_svc_action_name{_rand}'
    ver = _rand
    Content = json.dumps(c_onten)
    response = ssmclient.create_document(Name=Name, Content=Content,\
            DocumentType='Automation', VersionName=ver, DocumentFormat='JSON', TargetType=TargetType)
    _ret = {"Name": response['DocumentDescription']['Name'], "version": \
            response['DocumentDescription']['VersionName'], "Status":\
            response['DocumentDescription']['Status'],"Description":\
            response['DocumentDescription']['Description'],\
            "AssumeRole":"LAUNCH_ROLE"
    }
    return _ret
 

def sc_manage_service_action(_properties, action):
    _ret ={}
    IdempotencyToken = "tok%s" % str(
        random.randint(134324, 12342400))
    if action == 'Create':
        Para = [{ "Name":"KeyId","Type": "TARGET"},{ "Name":"QueueUserArn","Type": "TEXT_VALUE"}]
        #Para = [{ "Name":"KeyId","Type": "TARGET"},{ "Name":"AutomationAssumeRole","Type": "TEXT_VALUE"},{ "Name":"QueueUserArn","Type": "TEXT_VALUE"}]
        aParameters = json.dumps(Para)
        _ret = sc_client.create_service_action(Name=_properties['Name'], DefinitionType='SSM_AUTOMATION',\
                Definition={'Name': _properties['Name'],"Version":"1",  "AssumeRole": "LAUNCH_ROLE",\
                "Parameters": aParameters},\
                Description=_properties['Description'], AcceptLanguage='en', IdempotencyToken=IdempotencyToken)
    if action == 'Delete':
        return 'Deleting'
    return _ret

def sc_deleteaction(ProductId):
    response = sc_client.describe_product_as_admin(AcceptLanguage='en', Id=ProductId)
    ProvisioningArtifactId = response['ProvisioningArtifactSummaries'][0]['Id']
    sid = sc_client.list_service_actions_for_provisioning_artifact(
        ProductId=ProductId, ProvisioningArtifactId=ProvisioningArtifactId, AcceptLanguage='en')
    scactions = sid['ServiceActionSummaries']
    print('Disassociating..')
    for sc_seraction in scactions:
        sc_client.disassociate_service_action_from_provisioning_artifact\
                (ProductId=ProductId, ProvisioningArtifactId=ProvisioningArtifactId, \
                AcceptLanguage='en', ServiceActionId=sc_seraction['Id'])
    print('Deleting..')
    for sc_seraction in scactions:
        deleted_action = sc_client.delete_service_action(
            AcceptLanguage='en', Id=sc_seraction['Id'])
    return deleted_action
 
    
def sc_associtate_sa(prodinfo):
    _ret = sc_client.associate_service_action_with_provisioning_artifact(
                    ProductId=prodinfo['ProductId'], ProvisioningArtifactId=prodinfo['ProvisioningArtifactId'],\
                            ServiceActionId=prodinfo['ServiceActionId'], AcceptLanguage='en')
    return _ret
    

def cfnresponse(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + \
        context.log_stream_name
    responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']
    responseBody['NoEcho'] = noEcho
    responseBody['Data'] = responseData
    json_responseBody = json.dumps(responseBody)
    headers = {'content-type': '',
               'content-length': str(len(json_responseBody))}
    try:
        response = http.request(
            'PUT', event['ResponseURL'], body=json_responseBody.encode('utf-8'), headers=headers)
        logger.debug('Status code: ' + response.reason)
    except Exception as e:
        logger.error(
            'cfnresponse(..) failed executing requests.put(..): ' + str(e))


def timeout(event, context):
    logging.error(
        'Execution is about to time out, sending failure response to CloudFormation')
    cfnresponse(event, context, 'FAILED')


def lambda_handler(event, context):
    print(json.dumps(event))
    _ret = {}
    timer = threading.Timer((context.get_remaining_time_in_millis()
                             / 1000.00) - 0.5, timeout, args=[event, context])
    timer.start()
    status = 'SUCCESS'
    try:
        if event['RequestType'] == 'Create':
            _ret['status'] = 'Creating'
            resp_ssmdoc = cr_ssmdoc(event) 
            resp_action = sc_manage_service_action(resp_ssmdoc, 'Create')
            prodinfo = {
                "ServiceActionId":resp_action['ServiceActionDetail']['ServiceActionSummary']['Id'],
                "ProductId":event['ResourceProperties']['ProductId'],
                "ProvisioningArtifactId":event['ResourceProperties']['ProductArtifactId']
            }
            _ret['aa'] = sc_associtate_sa(prodinfo)
            ssmpname = f"/scqueue-{event['ResourceProperties']['ProductArtifactId']}"
            print(ssmpname)
            put_ssm_para(ssmpname,resp_ssmdoc['Name'])
        if event['RequestType'] == 'Delete':
            _ret['status'] = 'Delete'
            sc_deleteaction(event['ResourceProperties']['ProductId'])
            ssmpname =f"/scqueue-{event['ResourceProperties']['ProductArtifactId']}"
            dssmpname = get_ssm_para(ssmpname)
            response = ssmclient.delete_document(Name=dssmpname)
            del_ssm_para(ssmpname)
    except Exception as e:
        logging.error('Exception: %s' % e, exc_info=True)
        status = 'FAILED'
    finally:
        timer.cancel()
        cfnresponse(event, context, status, _ret)